# 简介

    假勤统计模块
    Author: rongqb@yonyou.com
    Date: 20190507

## 结构说明

### 1. 打卡原始记录（attendance） 
### 2. 休假统计（leave） 
### 3. 出差统计（trip） 
### 4. 加班统计（overtime） 