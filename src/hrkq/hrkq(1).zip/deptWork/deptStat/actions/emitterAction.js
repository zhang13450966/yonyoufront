/*
 * @Author: caoqj
 * @mail: caoqj@yonyou.com
 * @Date: 2020-04-17 15:23:03
 */
const EventEmitter = require('events').EventEmitter;
let emitter = new EventEmitter();
export default emitter;