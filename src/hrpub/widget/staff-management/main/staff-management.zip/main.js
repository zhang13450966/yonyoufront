/**
 * Created by wanghongxiang on 2018/3/22.
 */
import React, {Component} from 'react';
import Img from './download.svg';
import {
        widgetId,
        widgetName,
        serviceCode,
        serviceType,
} from 'widgetInstance';
import {dispatch} from 'widgetTool';
import {wrap, titleContainer, title, conLeft, iconL, textL, textL_below, conRight, iconR, svg} from './index.css'
class Attend extends Component {
    constructor() {
        super();
        this.state = {
            staffNumber : '0',
            entryNum : '0'
        };
        this.clickHandler = this.clickHandler.bind(this);
        this.reRreshPage = this.reRreshPage.bind(this);
    }
    toThousands(num) {
        if (!num || isNaN(num)) {
            return 0
        } else if(num<=999999){
          return (num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
        }else{
          return '999,999+'
        }
      }
    getErrCount(url, type) {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);//http://workbench.yyuap.com
        xhr.withCredentials = true;
        xhr.send();
        xhr.onreadystatechange = () =>{
            if(xhr.readyState === 4 && xhr.status === 200){
                let getStatus = JSON.parse(xhr.responseText);
                let data = ''
                if (type === 'staffNumber') {
                    data = getStatus.data;
                } else {
                    data = getStatus.data.count;
                }
                data = this.toThousands(data)
                if (type === 'staffNumber') {
                    this.setState({
                        staffNumber : data,
                      })
                } else {
                    this.setState({
                        entryNum : data,
                      })
                }
            }else {
                if (type === 'staffNumber') {
                    this.setState({
                        staffNumber : this.state.staffNumber,
                      })
                } else {
                    this.setState({
                        entryNum : this.state.entryNum,
                      })
                }
            }
        }
    }
    componentDidMount(){
        // this.getErrCount('http://hrcloud.yyuap.com/corehr-staff-mgr/corehr/staff/queryTeamStaffCount', "staffNumber")
        // this.getErrCount('http://hrcloud.yyuap.com/corehr-staff-process/corehr/entry/queryTeamEntryCount', "entryNum")
        this.getErrCount('https://hr.diwork.com/corehr-staff-mgr/corehr/staff/queryTeamStaffCount', "staffNumber")
        this.getErrCount('https://hr.diwork.com/corehr-staff-process/corehr/entry/queryTeamEntryCount', "entryNum")
    }
    clickHandler(e) {
        e.preventDefault();
        dispatch('openService', {
            serviceCode,
            data:{},
            type:serviceType,
        })
    }
    reRreshPage (e) {
        e.preventDefault();
        e.stopPropagation();
        // this.getErrCount('http://hrcloud.yyuap.com/corehr-staff-mgr/corehr/staff/queryTeamStaffCount', "staffNumber")
        // this.getErrCount('http://hrcloud.yyuap.com/corehr-staff-process/corehr/entry/queryTeamEntryCount', "entryNum")
        this.getErrCount('https://hr.diwork.com/corehr-staff-mgr/corehr/staff/queryTeamStaffCount', "staffNumber")
        this.getErrCount('https://hr.diwork.com/corehr-staff-process/corehr/entry/queryTeamEntryCount', "entryNum")
    }
    render() {
        return (
            <div className={wrap} onClick={this.clickHandler}>
                <div className={titleContainer}>
                    <div className={title}>
                        人员管理
                    </div>
                </div>
                <div className={conLeft}>
                    <div className={iconL}></div>
                    <div className={textL}>{this.state.staffNumber}</div>
                    <div className={textL_below}>在职员工数量</div>
                    <div>
                        <a onClick={this.reRreshPage}>
                            <img className={svg} src={Img} />
                        </a>
                    </div>
                </div>
                <div className={conRight}>
                    <div className={iconR}></div>
                    <div className={textL}>{this.state.entryNum}</div>
                    <div className={textL_below}>待入职人数</div>
                </div>
            </div>
        )
    }

}
export default Attend;
